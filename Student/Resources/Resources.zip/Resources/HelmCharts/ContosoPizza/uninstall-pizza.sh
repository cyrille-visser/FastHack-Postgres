helm uninstall wth-postgresql
helm uninstall wth-mysql
helm uninstall mysql-contosopizza
helm uninstall postgres-contosopizza
echo ""
echo "Use 'kubectl get ns' to make sure your pods are not in a Terminating status before redeploying"
